Run RunTests from MTMEscapy folder,
use:
chmod 777 ../*
../RunTests
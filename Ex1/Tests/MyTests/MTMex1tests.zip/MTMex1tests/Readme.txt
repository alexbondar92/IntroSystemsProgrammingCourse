Instructions: 
1.Extract the WHOLE folder to the csl2 server, under ex1 directory (or whatever other main directory for this ex you use).
2.Make sure PATH is set to your scripts folder.
3.Make sure you have permissions for the Runtest script(chmod 700 Runtest).
4.Navigate to the MTMEscapy directory under the MTMex1tests folder.
5.Write in shell and execute the following command : "../Runtest".
6.Enjoy the tests.

Of course you can add your own tests, just keep the format right
.input for input, .output for user output and .expout for expected output

Hopefully will add more tests.
